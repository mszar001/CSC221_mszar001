#11-1 City, Country

def city_country(city, country, population=None):
    if population:
        sorted_name = (f"{city.title()}, {country.title()} - population= {population}")
    else:
        sorted_name = (f"{city}, {country}").title()
    return sorted_name
  
print(city_country('city', 'country', '50'))
